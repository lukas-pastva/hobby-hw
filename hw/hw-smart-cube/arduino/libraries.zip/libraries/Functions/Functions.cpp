#include <Functions.h>
#include <Wire.h>

void append(char* s, char c) {
  int len = strlen(s);
  s[len] = c;
  s[len+1] = '\0';
}

bool strContains(char* needle, String haystack){
    int pos = haystack.indexOf(needle);
    if(pos>-1){
      return true;
    }else{
      return false;     
    }
}

char* i2cScan(){
	
  char * i2cReturnVal = "";    
  byte error, address;
  int nDevices;

  Serial.println("Scanning I2C.");

  nDevices = 0;
  for(address = 1; address < 127; address++ ) 
  {
    Wire.beginTransmission(address);
    error = Wire.endTransmission();

    if (error == 0) {
      Serial.print("I2C device found at address 0x");	  
      if (address<16) {
		sprintf(i2cReturnVal, "I2C at address 0x%d", (int)0);
        Serial.println("0");
	  }else{
		Serial.println(address,HEX);
		sprintf(i2cReturnVal, "I2C at address 0x%d", (int)address);
	  }
      nDevices++;
    } else if (error==4) {
      Serial.print("Unknown error at address 0x");
      if (address<16) {
        Serial.print("0");
	  }
      Serial.println(address,HEX);
    }
  }
  if (nDevices == 0){
    Serial.println("No I2C devices found\n");
  }
  return * i2cReturnVal;
}