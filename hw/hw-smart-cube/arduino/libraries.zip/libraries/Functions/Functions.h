#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H
#include <Arduino.h>

//extern void blink();
extern void append(char* s, char c);

extern bool strContains(char* needle, String haystack);

extern char * i2cScan();

#endif