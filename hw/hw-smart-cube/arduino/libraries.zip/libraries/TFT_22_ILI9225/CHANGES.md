TFT_22_ILI9225
==============

**v1.3.6, released 2018-03-01, Add high speed color drawBitmap function** Credit: [LAK132](https://github.com/LAK132)

**v1.3.5, released 2018-02-27, Stm32 f1 support and speeding up the library** Credit: [MicroBahner](https://github.com/MicroBahner)

**v1.3.4, released 2017-11-27, add support for ESP32**

**v1.3.3, released 2017-11-26, add support for STM32F1** Credit: [nicolasimeoni](https://github.com/nicolasimeoni)

**v1.3.2, released 2017-11-20, add triangle function demo**

**v1.3.1, released 2017-11-12, bug fixes for triangle functions**

**v1.3.0, released 2017-11-01, adds support for GFX type proportional fonts**

**v1.2.7, released 2017-10-30, fixes bug for ESP8266**

**v1.2.6, released 2017-10-27, adds support for all platforms**

**v1.2.3, released 2017-10-22, adds backlight brightness control** Credit: [miro1360](https://github.com/miro1360)

**v1.2.1, released 2017-09-18, fixed color table shift error**

**v1.2.0, released 2017-01-18, speeds up Hardware SPI significantly**
